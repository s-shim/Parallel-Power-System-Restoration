The result of Figure 4 are shown in two files, Figure4_FRR_Centroid100_summary.xls and Figure4_TreeSolutions100Summary.xls

The result of Figure 5, its input files and python codes are in folder 'Figure5_IEEE-118'
