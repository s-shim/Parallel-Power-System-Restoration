log files and solution files for Figure 5 
For your own computational experiments, you may run a python code in folder 'code'.