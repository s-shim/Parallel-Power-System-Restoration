Enhancement of the integer linear programming on IEEE-118

Run multiRuns20220701.py for each run to perform a sequence of three upperbounding approaches: Tree Partitioning, Local Search and Subgraph Partitioning 
Set numberOfRuns = ? (the number of runs)
The code sequentially perform multiple runs. (1 run = 8 cores)
The code can be modified to perform the multiple runs simultaneously on parallel machine. (1 supercomputing node = 16 runs = 128 cores)


For example, folder 'output' has the result from one run.
rep0_opt_PPSRT(RST)_p38_v24_CPUT146s.csv is the optimal solution to the tree partitioning problem.(rep0_RST.csv is the random spanning tree which is the minimum spanning tree on the random weight in rep0_lines.csv.) The algorithm started with upper bound 38 periods, and the optimal value is 24 periods. It is performed for 146 seconds.
rep0_opt_LS_p24_v21_CPUT150s.csv is the resultng solution from the local search method. The resulting value is 21 periods. It took 150 seconds.
rep0_opt_PPSR_QiuLi_warm_v20_CPUT265s.csv is the final solution on the subgraph (rep0_RST(x)Plus.csv) to the subgraph partition problem. The final value is 20 periods which is optimal to the original PPSR problem. The final algorithm took 265 seconds.


Input files are
IEEE118_6BS_20210216_res5min_p60.csv
lines_118.csv

IEEE118_6BS_20210216_res5min_p60.csv has node information as follows
Bus: Bus ID	
Type: BS nodes, NBS nodes, Trans (Transshipment nodes), CL (Critical Load)	
Capacity (MW)	
Cranking Power (MW)	
Cranking Time (h)	
Ramping Time (h)	
Cranking Time (5 min)	
Ramping Time (5 min)	
period1

lines_118.csv
Line (Transmission Line ID)	
Source, Target (Two End Nodes of each Edge)



