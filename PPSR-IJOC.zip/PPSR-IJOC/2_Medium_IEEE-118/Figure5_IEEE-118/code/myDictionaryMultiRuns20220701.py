from gurobipy import *
import pandas as pd
import networkx as nx
import myDictionary20220701 as md
import time
import random as rd


def minST(rep, lines):
    G = nx.Graph()
    for l in lines['Line']:
        [Source] = lines.loc[lines['Line'] == l,'Source']
        [Target] = lines.loc[lines['Line'] == l,'Target']
        [weight_l] = lines.loc[lines['Line'] == l,'weight']
        G.add_edge(Source,Target,weight=weight_l)
    
    mst = nx.minimum_spanning_tree(G)
    
    sources = []
    targets = []
    lineNumber = 0
    lineList = []
    for (source_l,target_l) in mst.edges():
        sources += [source_l]
        targets += [target_l]
        lineNumber += 1
        lineList += [lineNumber]
        
    return pd.DataFrame(list(zip(lineList,sources,targets)),columns =['Line','Source','Target'])



def PPSRT(rep, lines, nodes, timeHorizon):
    G = nx.Graph()
    for l in lines['Line']:
        [Source] = lines.loc[lines['Line'] == l,'Source']
        [Target] = lines.loc[lines['Line'] == l,'Target']
        G.add_edge(Source,Target)
    
    bsGenerators = []
    setI = []
    setTrans = []
    for v in nodes['Bus']:
        [genType] = nodes.loc[nodes['Bus'] == v,'Type']
        if genType == 'BS':
            bsGenerators += [v]
        if genType == 'NBS':
            setI += [v]
        if genType == 'CL':
            setI += [v]
            
        if genType == 'Trans':
            setTrans += [v]
    
    # construct the spanning arborescences
    spanArb = {}
    for gen in bsGenerators:
        spanArb[gen] = nx.DiGraph()
        spanArb[gen].add_node(gen)
        tempInIsland = [gen]
        tempOutOfIsland = []
        for v in G.nodes():
            if v != gen:
                tempOutOfIsland += [v]
        while len(tempOutOfIsland) > 0:
            for (u,v) in G.edges():
                if u in tempInIsland and v in tempOutOfIsland:
                    spanArb[gen].add_edge(u,v)
                    tempInIsland.append(v)
                    tempOutOfIsland.remove(v)
        
                if v in tempInIsland and u in tempOutOfIsland:
                    spanArb[gen].add_edge(v,u)
                    tempInIsland.append(u)
                    tempOutOfIsland.remove(u)
                
        print(gen,len(spanArb[gen].nodes()),nx.is_arborescence(spanArb[gen]))
    
    # ILP Model
    model = Model('PPSR')
    
    model.setParam('Threads', 8)
    #model.setParam('StartNodeLimit', 2000000000)
    #model.setParam('Cuts', 3)
    #model.setParam('MIPFocus', 3)
    #model.setParam('Method', 3)
    model.setParam('LogFile', 'rep%s_log_PPSRT(RST)_p%s.txt'%(rep,timeHorizon))
    
    
    x_vars = []
    x_names = []
    for v in G.nodes():
        for gen in bsGenerators:
            x_vars += [(v,gen)]
            x_names += ['X[%s,%s]'%(v,gen)]
            #print('X[%s,%s]'%(v,gen))
    X = model.addVars(x_vars, vtype = GRB.BINARY, name = x_names)
    
    start_vars = []
    start_names = []
    for j in bsGenerators:
        for i in setI:
            [type_i] = nodes.loc[nodes['Bus'] == i,'Type']
            for t in range(1,timeHorizon + 1):
                start_vars += [(j,i,t)]
                start_names += ['start[%s,%s,%s]'%(j,i,t)]    
    start = model.addVars(start_vars, vtype = GRB.BINARY, name = start_names)
    
    bottleneck = model.addVar(vtype=GRB.CONTINUOUS, name="bottleneck")
    
    ## Variable Options
    #X.BranchPriority = 1
    
    
    # Add constraints for network partition
    ## Add Boundary Constaints for the Fixed Centers
    for gen in bsGenerators:
        LHS = [(1,X[gen,gen])]
        model.addConstr(LinExpr(LHS)==1, name='Eq.boundaryIsland(%s)'%gen)
    
    ## Add Partition Equations
    for v in G.nodes():
        LHS = []
        for gen in bsGenerators:
            LHS += [(1,X[v,gen])]
        model.addConstr(LinExpr(LHS)==1, name='Eq.partition(%s)'%v)
    
    ## Add Arborescence Constraints
    for gen in bsGenerators:
        for (parent,child) in spanArb[gen].edges():
            LHS = [(1,X[parent,gen]),(-1,X[child,gen])]
            model.addConstr(LinExpr(LHS)>=0, name='Eq.Arborescence(%s,%s,%s)'%(parent,child,gen))
    
    # Add constraints for scheduling
    ## Start Time Selection Constraints
    for j in bsGenerators:
        for i in setI:
            LHS = [(-1,X[i,j])]
            for t in range(1,timeHorizon + 1):
                LHS += [(1,start[j,i,t])]
            model.addConstr(LinExpr(LHS)==0, name='Eq.startTimeSelection(%s,%s)'%(j,i))    
    
    ## Power Aggregation Constraints
    for j in bsGenerators:           
        for t in range(1,timeHorizon + 1):
            periodNameBS = "period%s"%t
            [powerOutput_j_t] = nodes.loc[nodes['Bus'] == j,periodNameBS]
            aggregation = []
            for i in setI:
                for earlierT in range(1,t+1):
                    relationT = t - earlierT + 1
                    periodName = "period%s"%relationT
                    [powerOutput_i_t] = nodes.loc[nodes['Bus'] == i,periodName]
                    aggregation += [(powerOutput_i_t,start[j,i,earlierT])] 
            model.addConstr(LinExpr(aggregation)>=-powerOutput_j_t, name='Eq(powerAggregate)(%s,%s)'%(j,t))
    
    ## Bottleneck 
    for i in setI:
        LHS = [(1,bottleneck)]
        for j in bsGenerators:
            for t in range(1,timeHorizon + 1):
                LHS += [(-t, start[j,i,t])]
        model.addConstr(LinExpr(LHS)>=0, name='Eq.bottleneck(%s)'%(i))    
    
    # =============================================================================
    # ## [ET, LT] 
    # for i in setI:
    #     [ET_i] = nodes.loc[nodes['Bus'] == i,'ET (5 min)']
    #     [LT_i] = nodes.loc[nodes['Bus'] == i,'LT (5 min)']
    #     LHS_ET = []
    #     LHS_LT = []
    #     for j in bsGenerators:
    #         for t in range(1,timeHorizon + 1):
    #             LHS_ET += [(t, start[j,i,t])]
    #             LHS_LT += [(t, start[j,i,t])]
    #     model.addConstr(LinExpr(LHS_ET)>=ET_i, name='Eq.ET(%s)'%(i))    
    #     model.addConstr(LinExpr(LHS_LT)<=LT_i, name='Eq.LT(%s)'%(i))  
    # =============================================================================
        
    # =============================================================================
    # # Fix Variables   
    # incumbent = pd.read_csv('opt_IEEE118_6BS_FixZ_p60.csv')
    # for j in bsGenerators:
    #     for i in G.nodes():
    #         var_name = 'X[%s,%s]'%(i,j)
    #         for var_name_incumbent in incumbent['varName']:
    #             if var_name == var_name_incumbent:
    #                 [var_value] = incumbent.loc[incumbent['varName'] == var_name,'varVal']
    #                 model.addConstr(LinExpr([(1,X[i,j])])==var_value, name='Eq.FixX(%s,%s)'%(i,j)) 
    #                 print(var_name)
    # =============================================================================
    
    # Objective Function
    ## Objective Terms
    objTerms = [(1,bottleneck)]                                
    model.setObjective(LinExpr(objTerms), GRB.MINIMIZE)
    
    
    # =============================================================================
    # # Warm Start   
    # incumbent = pd.read_csv('opt_20_118.csv')
    # for j in bsGenerators:
    #     for i in G.nodes():
    #         var_name = 'X[%s,%s]'%(i,j)
    #         for var_name_incumbent in incumbent['varName']:
    #             if var_name == var_name_incumbent:
    #                 [var_value] = incumbent.loc[incumbent['varName'] == var_name,'varVal']
    #                 if var_value == 1:
    #                     X[i,j].start = 1.0
    #                     print(var_name,'=',var_value)
    # =============================================================================
            
    
    # update and solve the model
    model.update()
    model.optimize()
    
    #toc = time.time()
    #print('CPU Time = ', toc - tic)
    
    # read the optimal solution
    variableName = []
    variableValue = []
    for v in model.getVars():
        if v.x > 0:
            variableName += [v.varname]
            variableValue += [v.x]
    
    
    optSolution = pd.DataFrame(list(zip(variableName, variableValue)),columns =['varName', 'varVal'])
    obj = model.getObjective()
    BNT = obj.getValue()

    return optSolution, BNT

    #optSolution.to_csv(r'opt_PPSRT(RST-rep4)_p22.csv', index = False)#Check
    



def LS(rep,threads, timeHorizon,lines,nodes,incumbent):
    G = nx.Graph()
    for l in lines['Line']:
        [Source] = lines.loc[lines['Line'] == l,'Source']
        [Target] = lines.loc[lines['Line'] == l,'Target']
        G.add_edge(Source,Target)
    
    bsGenerators = []
    setI = []
    for v in nodes['Bus']:
        [genType] = nodes.loc[nodes['Bus'] == v,'Type']
        if genType == 'BS':
            bsGenerators += [v]
        if genType == 'BS+NBS':
            bsGenerators += [v]
        if genType == 'NBS':
            setI += [v]
        if genType == 'CL':
            setI += [v]
    
    
    # construct subgraph subG[gen] for gen in bsGenerators
    subG = {}
    for gen in bsGenerators:
        subG[gen] = nx.Graph()
        subNodes = []
        for i in G.nodes():
            var_name = 'X[%s,%s]'%(i,gen)
            for var_name_incumbent in incumbent['varName']:
                if var_name == var_name_incumbent:
                    [var_value_incumbent] = incumbent.loc[incumbent['varName'] == var_name,'varVal']
                    if var_value_incumbent == 1:
                        subNodes += [i]
        subG[gen] = G.subgraph(subNodes)
    
    print('calculate bottleneck time of each island...')
    # calculate bottleneck time of each island
    bnislands = []
    islands = []
    for gen in bsGenerators:
        gen_island = gen
        setI_island = []
        for v in nodes['Bus']:
            if v in subG[gen_island].nodes():
                [genType] = nodes.loc[nodes['Bus'] == v,'Type']
                if genType == 'NBS':
                    setI_island += [v]
                if genType == 'CL':
                    setI_island += [v]
    
        bnTime_gen = md.GSS(timeHorizon,nodes,gen_island,setI_island)
        print('##########Bottleneck time of Island %s is %s'%(gen,bnTime_gen))
        print('##########Nodes of island %s are'%gen,':',subG[gen].nodes())
        bnislands += [int(bnTime_gen)]
        islands += [gen] 
    
    timeTable = pd.DataFrame(list(zip(islands, bnislands)),columns =['BS', 'Bottleneck'])
    
    tic = time.time()
    print('Start local search............')
    improve = 1
    while improve == 1:
        improve = 0
        timeTable_sorted = timeTable.sort_values(['Bottleneck'])
        maxBS = timeTable_sorted['BS'].iloc[len(islands)-1]
        maxTime = timeTable_sorted['Bottleneck'].iloc[len(islands)-1]
        for num in range(len(islands)-1):
            minBS = timeTable_sorted['BS'].iloc[num]
            unionNodes = []
            for v in subG[maxBS].nodes():
                unionNodes += [v]
            for v in subG[minBS].nodes():
                unionNodes += [v]
            unionSubG = G.subgraph(unionNodes)
            if nx.has_path(unionSubG,minBS,maxBS) == 1:    
                print('###############Merge Max Island:',maxBS,' with ',len(subG[maxBS].nodes()),' nodes ')
                print('###############Merge min Island:',minBS,' with ',len(subG[minBS].nodes()),' nodes ')
                optLocal, optSolTable = md.solvePPSR(unionSubG,nodes,lines,int(maxTime),threads)    
                if optLocal < maxTime:
                    improve = 1
                    print(maxBS,minBS,optLocal)
                    minNodes = []
                    maxNodes = []                
                    for var_name in optSolTable['varName']:
                        for v in unionSubG.nodes():
                            if var_name == 'X[%s,%s]'%(v,minBS):
                                minNodes += [v]
        
                            if var_name == 'X[%s,%s]'%(v,maxBS):
                                maxNodes += [v]
                                
                    subG[minBS] = G.subgraph(minNodes)
                    subG[maxBS] = G.subgraph(maxNodes)
                    
                    for gen in [minBS,maxBS]:
                        gen_island = gen
                        setI_island = []
                        for v in nodes['Bus']:
                            if v in subG[gen_island].nodes():
                                [genType] = nodes.loc[nodes['Bus'] == v,'Type']
                                if genType == 'NBS':
                                    setI_island += [v]
                                if genType == 'CL':
                                    setI_island += [v]
                                    
                        bnTime_gen = md.GSS(int(optLocal),nodes,gen_island,setI_island)
                        tempBS = []
                        tempTime = []
                        for bsTemp in timeTable['BS']:
                            if bsTemp == gen_island:
                                tempBS += [bsTemp]
                                tempTime += [int(bnTime_gen)]
                            if bsTemp != gen_island:
                                tempBS += [bsTemp]
                                [timeOne] = timeTable.loc[timeTable['BS'] == bsTemp,'Bottleneck']
                                tempTime += [timeOne]
                                
                        timeTable = pd.DataFrame(list(zip(tempBS,tempTime)),columns =['BS','Bottleneck'])
        
                    break
    
    
    toc = time.time()
    CPUT = toc - tic
    print('###########Elapse Time for Local Search = ',toc-tic)
    print('Construct an initial solution.......')
    var_name = []
    var_value = []
    for gen in bsGenerators:
        for v in subG[gen].nodes():
            var_name += ['X[%s,%s]'%(v,gen)]
            var_value += [1]
    warm = pd.DataFrame(list(zip(var_name,var_value)),columns =['varName','varVal'])
    
    timeTable_sorted = timeTable.sort_values(['Bottleneck'])
    maxBS = timeTable_sorted['BS'].iloc[len(islands)-1]
    maxTime = timeTable_sorted['Bottleneck'].iloc[len(islands)-1]
    
    print('######### Warm Start Ready PPSR with warm objective = %s'%maxTime)
    # =============================================================================
    # optValue, optSolution = md.warmSolvePPSR(G,nodes,lines,int(maxTime),warm)
    # optSolution.to_csv(r'opt_PPSR_118_6BS_20210216_res5min_p%s.csv'%timeHorizon, index = False)#Check
    # =============================================================================
                
    return warm, maxTime, CPUT




def RSTPlus(lines,nodes,incumbent,rep):
    G = nx.Graph()
    for l in lines['Line']:
        [Source] = lines.loc[lines['Line'] == l,'Source']
        [Target] = lines.loc[lines['Line'] == l,'Target']
        G.add_edge(Source,Target)
    #print(len(G.edges()))
    
    bsNodes = []
    setI = []
    for v in nodes['Bus']:
        [genType] = nodes.loc[nodes['Bus'] == v,'Type']
        if genType == 'BS':
            bsNodes += [v]
        if genType == 'NBS':
            setI += [v]
        if genType == 'CL':
            setI += [v]
    
    bsTable = nodes.loc[nodes['Type']=='BS']
    bsGenerators = bsTable.sort_values(by='Capacity (MW)',ascending=False)
    
    island = {}
    treeIsland = {}
    for j in bsGenerators['Bus']:
        node_j = []
        for v in G.nodes():
            for var_name in incumbent['varName']:
                if var_name == 'X[%s,%s]'%(v,j):
                    [var_value] = incumbent.loc[incumbent['varName'] == var_name,'varVal']
                    if var_value > 0:
                        node_j += [v]
        island[j] = G.subgraph(node_j)
        treeIsland[j] = nx.bfs_tree(island[j],j,reverse=True)
        
    for (u,v) in G.edges():
        G[u][v]['weight'] = 0
    
    innerEdges = []
    treeEdges = 0
    for (u,v) in G.edges():
        for j in bsGenerators['Bus']:
            if (u,v) in island[j].edges():
                innerEdges += [(u,v)]
                weight_uv = 0
                if (u,v) in treeIsland[j].edges():
                    treeEdges += 1
                    weight_uv = len(G.nodes())
                if (v,u) in treeIsland[j].edges():
                    treeEdges += 1
                    weight_uv = len(G.nodes())
                G[u][v]['weight'] = weight_uv
                #print(u,v,'inner',':weight=',weight_uv)
    #print(len(innerEdges))
    globalEdges = []
    globalEdges_Source = []
    globalEdges_Target = []
    outerEdges = []
    globalEdgesList = []
    globalEdgesNumber = 0
    for (u,v) in G.edges():
        if (u,v) not in innerEdges:
            globalEdgesNumber += 1
            globalEdgesList += [globalEdgesNumber]
            globalEdges_Source += [u]
            globalEdges_Target += [v]
            globalEdges += [(u,v)]
            outerEdges += [(u,v)]
            G[u][v]['weight'] = rd.random()
            #print(u,v,G[u][v]['weight'])
    
    #print(len(outerEdges))
    
    for j in bsGenerators['Bus']:
        for (u,v) in treeIsland[j].edges():
            globalEdgesNumber += 1
            globalEdgesList += [globalEdgesNumber]
            globalEdges_Source += [u]
            globalEdges_Target += [v]
            globalEdges += [(u,v)]
    
    # =============================================================================
    # treeCutNumber = 0
    # treeCutList = []
    # sourceListTree = []
    # targetListTree = []
    # for (u,v) in globalEdges:
    #     treeCutNumber += 1
    #     treeCutList += [treeCutNumber]
    #     sourceListTree += [u]
    #     targetListTree += [v]
    # =============================================================================
    
        
    # =============================================================================
    # treeCutGlobal = pd.DataFrame(list(zip(treeCutList,sourceListTree,targetListTree)),columns =['Line','Source', 'Target'])
    # treeCutGlobal.to_csv(r'globalTreeCut.csv', index = False)#Check
    # =============================================================================
    
    T = nx.maximum_spanning_tree(G)
    
    lineList = []
    sourceList = []
    targetList = []
    lineNumber = 0
    for (u,v) in T.edges():
        lineNumber += 1
        lineList += [lineNumber]
        sourceList += [u]
        targetList += [v]
        
    treeGlobalPlus = pd.DataFrame(list(zip(globalEdgesList,globalEdges_Source,globalEdges_Target)),columns =['Line','Source', 'Target'])

    return treeGlobalPlus




def PPSR_QL_warm(rep,timeHorizon,lines,nodes,incumbent):
    G = nx.Graph()
    for l in lines['Line']:
        [Source] = lines.loc[lines['Line'] == l,'Source']
        [Target] = lines.loc[lines['Line'] == l,'Target']
        G.add_edge(Source,Target)
    
    bsGenerators = []
    setI = []
    for v in nodes['Bus']:
        [genType] = nodes.loc[nodes['Bus'] == v,'Type']
        if genType == 'BS':
            bsGenerators += [v]
        if genType == 'NBS':
            setI += [v]
        if genType == 'CL':
            setI += [v]
    # =============================================================================
    #     if genType == 'Trans':
    #         setI += [v]
    # =============================================================================
    
    experiment = 1
    #for experiment in range(11,31):    
    
    
    # ILP Model
    model = Model('PPSR-QiuLi')
    
    model.setParam('Threads', 8)
    #model.setParam('StartNodeLimit', 2000000000)
    model.setParam('Cuts', 3)
    model.setParam('MIPFocus', 3)
    model.setParam('LogFile', 'rep%s_gurobiLogPPSR_QiuLi_warm.txt'%rep)
    #model.setParam('SolFiles', 'gurobiSol')
    
    
    x_vars = []
    x_names = []
    for v in G.nodes():
        for gen in bsGenerators:
            x_vars += [(v,gen)]
            x_names += ['X[%s,%s]'%(v,gen)]
            #print('X[%s,%s]'%(v,gen))
    X = model.addVars(x_vars, vtype = GRB.BINARY, name = x_names)
    
    
    fql_vars = []
    fql_names = []
    for j in bsGenerators:
        for (u,v) in G.edges():
            fql_vars += [(u,v,j)]
            fql_names += ['FQL[%s,%s,%s]'%(u,v,j)]
    FQL = model.addVars(fql_vars, vtype = GRB.INTEGER, lb = -GRB.INFINITY, name = fql_names)
    
    
    yql_vars = []
    yql_names = []
    for j in bsGenerators:
        for (u,v) in G.edges():
            yql_vars += [(u,v,j)]
            yql_names += ['YQL[%s,%s,%s]'%(u,v,j)]
    YQL = model.addVars(yql_vars, vtype = GRB.BINARY, name = yql_names)
    
    
    start_vars = []
    start_names = []
    for j in bsGenerators:
        for i in setI:
            [type_i] = nodes.loc[nodes['Bus'] == i,'Type']
            for t in range(1,timeHorizon + 1):
                start_vars += [(j,i,t)]
                start_names += ['start[%s,%s,%s]'%(j,i,t)]    
    start = model.addVars(start_vars, vtype = GRB.BINARY, name = start_names)
    
    bottleneck = model.addVar(vtype=GRB.CONTINUOUS, name="bottleneck")
    
    ## Variable Options
    YQL.BranchPriority = 2
    #X.BranchPriority = 1
    
    
    # Add constraints for network partition
    ## Add Boundary Constaints for the Fixed Centers
    for gen in bsGenerators:
        LHS = [(1,X[gen,gen])]
        model.addConstr(LinExpr(LHS)==1, name='Eq.boundaryIsland(%s)'%gen)
        for gen2 in bsGenerators:
            if gen2 != gen:
                LHS2 = [(1,X[gen2,gen])]
                model.addConstr(LinExpr(LHS2)==0, name='Eq.boundaryIsland2(%s,%s)'%(gen2,gen))
    
    ## Add Partition Equations and Inequalities
    for v in G.nodes():
        if v in setI:
            LHS = []
            for gen in bsGenerators:
                LHS += [(1,X[v,gen])]
            model.addConstr(LinExpr(LHS)==1, name='Eq.partition(%s)'%v)
            #[genType] = nodes.loc[nodes['Bus'] == v,'Type']
            #print(v,genType)
    
    for v in G.nodes():
        if v not in setI:
            if v not in bsGenerators:
                LHS = []
                for gen in bsGenerators:
                    LHS += [(1,X[v,gen])]
                model.addConstr(LinExpr(LHS)<=1, name='Eq.partitionIneq(%s)'%v)
                #[genType] = nodes.loc[nodes['Bus'] == v,'Type']
                #print('trans',v,genType)
    
    ## Flow Conatraint
    ### Flow Value From i = X
    for j in bsGenerators:
        for i in setI:
            LHS = [(-1,X[i,j])]
            for (u,v) in G.edges():
                if u == i:
                    LHS += [(1,FQL[u,v,j])]
    
                if v == i:
                    LHS += [(-1,FQL[u,v,j])]
    
            model.addConstr(LinExpr(LHS)==0, name='Eq.pathFlowValue(%s,%s)'%(i,j))
            #[genType] = nodes.loc[nodes['Bus'] == i,'Type']
            #print('setI=',i,genType,'; gen=',j)
            
    
    ### Flow Conservative At Trans
    for j in bsGenerators:
        for i in G.nodes():
            if i not in setI:
                if i not in bsGenerators:
                    LHS = []
                    for (u,v) in G.edges():
                        if u == i:
                            LHS += [(1,FQL[u,v,j])]
            
                        if v == i:
                            LHS += [(-1,FQL[u,v,j])]
            
                    model.addConstr(LinExpr(LHS)==0, name='Eq.conservativeTrans(%s,%s)'%(i,j))
                    #[genType] = nodes.loc[nodes['Bus'] == i,'Type']
                    #print('trans',i,genType,'; gen=',j)
                    
    
    ### Flow Value Into j = sum of X
    for j in bsGenerators:
        LHS = []
        for i in setI:
            LHS += [(-1,X[i,j])]
            #print('(-1,X[%s,%s])'%(i,j))
    
        for (u,v) in G.edges():
            if u == j:
                LHS += [(-1,FQL[u,v,j])]
                #print('(-1,FQL[%s,%s,%s])'%(u,v,j))
    
            if v == j:
                LHS += [(1,FQL[u,v,j])]
                #print('(1,FQL[%s,%s,%s])'%(u,v,j))
    
        model.addConstr(LinExpr(LHS)==0, name='Eq.flowIntoJ(%s)'%(j))
    
    
    ### Eq 5: Flow Capacity on Edge
    for j in bsGenerators:
        for (u,v) in G.edges():
            LHS1 = [(1,FQL[u,v,j]),(-len(setI),YQL[u,v,j])]
            LHS2 = [(1,FQL[u,v,j]),(len(setI),YQL[u,v,j])]
            
            model.addConstr(LinExpr(LHS1)<=0, name='Eq.flowCap1(%s,%s,%s)'%(u,v,j))
            model.addConstr(LinExpr(LHS2)>=0, name='Eq.flowCap2(%s,%s,%s)'%(u,v,j))
    
            #print('(1,FQL[%s,%s,%s]),(-%s,YQL[%s,%s,%s])<=0'%(u,v,j,len(setI),u,v,j))
            #print('(1,FQL[%s,%s,%s]),(%s,YQL[%s,%s,%s])>=0'%(u,v,j,len(setI),u,v,j))
    
    
# =============================================================================
#     ### Eq 6: Degree Capacity at v
#     for j in bsGenerators:
#         for v in G.nodes():
#             LHS = [(-G.degree[v],X[v,j])]
#             #print('(-%s,X[%s,%s])'%((G.degree[v],v,j)))
#             for (u,w) in G.edges():
#                 if u == v: 
#                     LHS += [(1,YQL[u,w,j])]
#                     #print('(1,YQL[%s,%s,%s])'%(u,w,j))
#     
#                 if w == v: 
#                     LHS += [(1,YQL[u,w,j])]
#                     #print('(1,YQL[%s,%s,%s])'%(u,w,j))
#     
#             model.addConstr(LinExpr(LHS)<=0, name='Eq.degreeCap1(%s,%s)'%(v,j))
# =============================================================================
        

    ### Eq 7: Node Capacity on Edge
    for j in bsGenerators:
        for (u,v) in G.edges():
            LHS1 = [(1,X[u,j]),(-1,YQL[u,v,j])]
            LHS2 = [(1,X[v,j]),(-1,YQL[u,v,j])]
            
            model.addConstr(LinExpr(LHS1)>=0, name='Eq.NodeCap1(%s,%s,%s)'%(u,v,j))
            model.addConstr(LinExpr(LHS2)>=0, name='Eq.NodeCap2(%s,%s,%s)'%(u,v,j))
    
    
    # Add constraints for scheduling
    ## Start Time Selection Constraints
    for j in bsGenerators:
        for i in setI:
            LHS = [(-1,X[i,j])]
            for t in range(1,timeHorizon + 1):
                LHS += [(1,start[j,i,t])]
            model.addConstr(LinExpr(LHS)==0, name='Eq.startTimeSelection(%s,%s)'%(j,i))    
    
    ## Power Aggregation Constraints
    for j in bsGenerators:           
        for t in range(1,timeHorizon + 1):
            periodNameBS = "period%s"%t
            [powerOutput_j_t] = nodes.loc[nodes['Bus'] == j,periodNameBS]
            aggregation = []
            for i in setI:
                for earlierT in range(1,t+1):
                    relationT = t - earlierT + 1
                    periodName = "period%s"%relationT
                    [powerOutput_i_t] = nodes.loc[nodes['Bus'] == i,periodName]
                    aggregation += [(powerOutput_i_t,start[j,i,earlierT])] 
            model.addConstr(LinExpr(aggregation)>=-powerOutput_j_t, name='Eq(powerAggregate)(%s,%s)'%(j,t))
    
    ## Bottleneck 
    for i in setI:
        LHS = [(1,bottleneck)]
        for j in bsGenerators:
            for t in range(1,timeHorizon + 1):
                LHS += [(-t, start[j,i,t])]
        model.addConstr(LinExpr(LHS)>=0, name='Eq.bottleneck(%s)'%(i))    
    
    # =============================================================================
    # ## [ET, LT] 
    # for i in setI:
    #     [ET_i] = nodes.loc[nodes['Bus'] == i,'ET (5 min)']
    #     [LT_i] = nodes.loc[nodes['Bus'] == i,'LT (5 min)']
    #     LHS_ET = []
    #     LHS_LT = []
    #     for j in bsGenerators:
    #         for t in range(1,timeHorizon + 1):
    #             LHS_ET += [(t, start[j,i,t])]
    #             LHS_LT += [(t, start[j,i,t])]
    #     model.addConstr(LinExpr(LHS_ET)>=ET_i, name='Eq.ET(%s)'%(i))    
    #     model.addConstr(LinExpr(LHS_LT)<=LT_i, name='Eq.LT(%s)'%(i))  
    # =============================================================================
        
    # =============================================================================
    # # Fix Variables   
    # incumbent = pd.read_csv('opt_IEEE118_6BS_FixZ_p60.csv')
    # for j in bsGenerators:
    #     for i in G.nodes():
    #         var_name = 'X[%s,%s]'%(i,j)
    #         for var_name_incumbent in incumbent['varName']:
    #             if var_name == var_name_incumbent:
    #                 [var_value] = incumbent.loc[incumbent['varName'] == var_name,'varVal']
    #                 model.addConstr(LinExpr([(1,X[i,j])])==var_value, name='Eq.FixX(%s,%s)'%(i,j)) 
    #                 print(var_name)
    # =============================================================================
    
    # Objective Function
    ## Objective Terms
    objTerms = [(1,bottleneck)]                                
    model.setObjective(LinExpr(objTerms), GRB.MINIMIZE)
    
    
    # Warm Start   
    for j in bsGenerators:
        for i in G.nodes():
            var_name = 'X[%s,%s]'%(i,j)
            for var_name_incumbent in incumbent['varName']:
                if var_name == var_name_incumbent:
                    [var_value] = incumbent.loc[incumbent['varName'] == var_name,'varVal']
                    if var_value == 1:
                        X[i,j].start = 1.0
                        #print(var_name,'=',var_value)
            
    
    # update and solve the model
    model.update()
    model.optimize()
    
    #print(datetime.datetime.now())
    #toc = time.time()
    #print('CPU Time = ',toc - tic)
    
    # read the optimal solution
    variableName = []
    variableValue = []
    for v in model.getVars():
        if v.x > 0:
            variableName += [v.varname]
            variableValue += [v.x]
    
    optSolution = pd.DataFrame(list(zip(variableName, variableValue)),columns =['varName', 'varVal'])

    obj = model.getObjective()
    BNT = obj.getValue()

    return optSolution, BNT
