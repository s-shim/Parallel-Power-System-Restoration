Run randFeasible_LS20220721.py for the computational approach on PEG-1354
The code sequantially perform multiple runs of the computational approach.
The code can be modified to perform the multiple runs simultaneously. (1 run = 8 cores; 2 supercomputing nodes = 2 * 128 cores = 32 runs)
Each run is defined as 'rep' in the code.


You can find the computational result in folder 'result'.
For each run ('rep'), note the initial restoration time and the final restoration time.
'randLS_p40_rep32_allData_20220723.csv' is the result in 10 minutes of computational time.
'randLS_p40_tl1500_rep32_PC_20220727_allData.csv' is the result in 25 minutes.
