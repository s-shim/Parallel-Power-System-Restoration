#from gurobipy import *
import pandas as pd
import networkx as nx
import random as rd
import myDic_newRR20220721 as mdr
import myDictionary20220721 as md
import copy
import time
import math
import datetime

threads = 8
tic = time.time()
compTimeLimit = 1500 #seconds
timeHorizon = 40
lines = pd.read_csv('lines_json_1354.csv')
nodes = pd.read_csv('nodes_json_1354.csv')

stopping2 = 10

bsGenerators = []
setI = []
for node in nodes['Bus']:
    [type_node] = nodes.loc[nodes['Bus']==node,'Type']
    if type_node == 'BS':
        bsGenerators += [node]
    if type_node == 'NBS':
        setI += [node]
    if type_node == 'CL':
        setI += [node]

G = nx.Graph()
for line in lines['Line']:
    [source_line] = lines.loc[lines['Line']==line,'Source']
    [target_line] = lines.loc[lines['Line']==line,'Target']
    G.add_edge(source_line,target_line)

zeroExtG = nx.Graph()
for node in G.nodes():
    for bsNode in bsGenerators:
        zeroExtG.add_node((node,bsNode),relaxedValue = 0.0)

rExtG = nx.Graph()
for node in G.nodes():
    for bsNode in bsGenerators:
        rExtG.add_node((node,bsNode),relaxedValue = 1/len(bsGenerators))

extG = copy.deepcopy(rExtG)
    
rep = 0
bestRepList = [rep]
bottleneck = float(timeHorizon)
bestBottleneckList = [bottleneck]
toc = time.time()
compTimeList = [toc-tic]
trial = 0
bestTrialList = [trial]
stepList = [-1]
repeat2List = [-1]
initialSolution = 0

for rep in range(1,32+1):
    bottleneck = float(timeHorizon)
    trial = 0
    ticRep = time.time()
    step = 0
    alpha = 1/2
    while toc - ticRep < compTimeLimit and step <= 1:
        trial += 1
        if step == 0:
            island = mdr.roundingNew(G,rExtG,bsGenerators)
            
            rtIsland = {}        
            maxOptVal = -2.0
            for bsNode in bsGenerators:
                setI_island = list(set(setI) & set(island[bsNode]))
                optVal = 0.0
                if len(setI_island) > 0:
                    optVal = mdr.GSS(compTimeLimit,ticRep,int(bottleneck),nodes,bsNode,setI_island)
                    
                print(bsNode,len(island[bsNode]),optVal)
                print(nx.is_connected(G.subgraph(island[bsNode])))
        
                if optVal != 'INFEASIBLE' and optVal != 'TIME_LIMIT':
                    rtIsland[bsNode] = int(optVal+.5)        
                    if int(maxOptVal+.5) < int(optVal+.5):
                        maxOptVal = int(optVal + 0.5)            
                        
                if optVal == 'INFEASIBLE' or optVal == 'TIME_LIMIT':
                    rtIsland[bsNode] = timeHorizon + 1        
                    maxOptVal = optVal
                    break 
                
            if maxOptVal == 'INFEASIBLE':
                bsGenerators.remove(bsNode)
                bsGenerators = [bsNode] + bsGenerators

            if maxOptVal != 'INFEASIBLE' and maxOptVal != 'TIME_LIMIT':
                if int(bottleneck+.5) > int(maxOptVal+.5):
                    bottleneck = maxOptVal
                    bestExtG = copy.deepcopy(zeroExtG)
                    for bsNode in bsGenerators:
                        for node in island[bsNode]:
                            bestExtG.nodes[(node,bsNode)]['relaxedValue'] = 1.0
                    
                    bestBottleneckList += [bottleneck]
                    bestTrialList += [trial]
                    bestRepList += [rep]
                    toc = time.time()
                    compTimeList += [toc-ticRep]
                    stepList += [step]
                    
                    print('at trial = ',trial)
                    print('at step = ',step)
                    print('best known bottleneck = ',bottleneck)
                    step = 1
                    initialSolution = 1
                    
        if step == 1:
            # construct subgraph subG[gen] for gen in bsGenerators
            subG = {}
            for gen in bsGenerators:
                subG[gen] = G.subgraph(island[gen])

            print('calculate bottleneck time of each island...')
            # calculate bottleneck time of each island
            bnislands = []
            islands = []
            for gen in bsGenerators:
                print()
                print('##########Bottleneck time of Island %s is %s'%(gen,rtIsland[gen]))
                print('##########Size of island %s is'%gen,':',len(subG[gen].nodes()))
                bnislands += [rtIsland[gen]]
                islands += [gen] 
            
            timeTable = pd.DataFrame(list(zip(islands, bnislands)),columns =['BS', 'Bottleneck'])

            print('Start local search............')
            improve = 1
            bnNodes = []
            bnTimes = []
            bnCompTimes = []
            while toc - ticRep < compTimeLimit and improve == 1:
                improve = 0
                timeTable_sorted = timeTable.sort_values(['Bottleneck'])
                maxBS = timeTable_sorted['BS'].iloc[len(islands)-1]
                maxTime = timeTable_sorted['Bottleneck'].iloc[len(islands)-1]
                bnNodes += [maxBS]
                bnTimes += [maxTime]
                toc = time.time()
                bnCompTimes += [toc-ticRep]

                if initialSolution > 1:
                    bottleneck = maxTime
                    bestBottleneckList += [bottleneck]
                    bestTrialList += [trial]
                    bestRepList += [rep]
                    toc = time.time()
                    compTimeList += [toc-ticRep]
                    stepList += [step]

                initialSolution = 2
                
                for num in range(len(islands)-1):
                    minBS = timeTable_sorted['BS'].iloc[num]
                    unionNodes = []
                    for v in subG[maxBS].nodes():
                        unionNodes += [v]
                    for v in subG[minBS].nodes():
                        unionNodes += [v]
                    unionSubG = G.subgraph(unionNodes)
                    if nx.has_path(unionSubG,minBS,maxBS) == 1:    
                        print()
                        toc = time.time()
                        print('### Elapse Time So Far = ',toc-ticRep)
                        print('###############Merge min Island:',minBS,' with ',len(subG[minBS].nodes()),' nodes ','and RT =',rtIsland[minBS])
                        print('###############Merge Max Island:',maxBS,' with ',len(subG[maxBS].nodes()),' nodes ','and [RT] =',rtIsland[maxBS])
                        optLocal, optSolTable = md.solvePPSRDA_Limit(compTimeLimit,ticRep,unionSubG,nodes,lines,int(maxTime+.5),threads)    

                        if optLocal != 'INFEASIBLE' and optLocal != 'TIME_LIMIT':

                            if int(optLocal+.5) < int(maxTime+.5):
                                improve = 1
                                print('maxBS %s and minBS %s improved to %s'%(maxBS,minBS,optLocal))
                                minNodes = []
                                maxNodes = []                
                                for var_name in optSolTable['varName']:
                                    for v in unionSubG.nodes():
                                        if var_name == 'X[%s,%s]'%(v,minBS):
                                            minNodes += [v]
                    
                                        if var_name == 'X[%s,%s]'%(v,maxBS):
                                            maxNodes += [v]
                                            
                                subG[minBS] = G.subgraph(minNodes)
                                subG[maxBS] = G.subgraph(maxNodes)
                                
                                newMinNodes = nx.node_connected_component(subG[minBS], minBS)
                                newMaxNodes = nx.node_connected_component(subG[maxBS], maxBS)
                                if len(unionSubG.nodes()) > len(newMinNodes) + len(newMaxNodes): 
                                    print()
                                    print('###### !!!!! post process on islands %s and %s'%(minBS,maxBS))
                                    print('%s > %s + %s'%(len(unionSubG.nodes()),len(newMinNodes),len(newMaxNodes)))
                                    outOfComp = []
                                    for u in unionSubG.nodes():
                                        if u not in newMinNodes and u not in newMaxNodes:
                                            outOfComp += [u]
                                    while len(outOfComp) > 0: 
                                        outOfCompTemp = copy.deepcopy(outOfComp)
                                        for u in outOfCompTemp:
                                            newMinNodesTemp = newMinNodes.union({u})
                                            if nx.is_connected(G.subgraph(newMinNodesTemp)):
                                                newMinNodes = newMinNodes.union({u})
                                                outOfComp.remove(u)
                                            if not nx.is_connected(G.subgraph(newMinNodesTemp)):
                                                newMaxNodesTemp = newMaxNodes.union({u})
                                                if nx.is_connected(G.subgraph(newMaxNodesTemp)):
                                                    newMaxNodes = newMaxNodes.union({u})
                                                    outOfComp.remove(u)
                                    subG[minBS] = G.subgraph(newMinNodes)
                                    subG[maxBS] = G.subgraph(newMaxNodes)
                                    print()
                                    print('minBS %s is connected = '%minBS,nx.is_connected(subG[minBS]))
                                    print('maxBS %s is connected = '%maxBS,nx.is_connected(subG[maxBS]))
                                    print('%s = %s + %s'%(len(unionSubG.nodes()),len(newMinNodes),len(newMaxNodes)))
                                    print()
                                
                                for gen in [minBS,maxBS]:
                                    gen_island = gen
                                    setI_island = []
                                    for v in nodes['Bus']:
                                        if v in subG[gen_island].nodes():
                                            [genType] = nodes.loc[nodes['Bus'] == v,'Type']
                                            if genType == 'NBS':
                                                setI_island += [v]
                                            if genType == 'CL':
                                                setI_island += [v]
                                                
                                    bnTime_gen = md.GSS(int(optLocal+.5),nodes,gen_island,setI_island)
                                    tempBS = []
                                    tempTime = []
                                    for bsTemp in timeTable['BS']:
                                        if bsTemp == gen_island:
                                            tempBS += [bsTemp]
                                            tempTime += [int(bnTime_gen+.5)]
                                            rtIsland[gen_island] = int(0.5+bnTime_gen)
                                            print('resulting RT of island %s of size %s='%(gen_island,len(subG[gen_island].nodes())),rtIsland[gen_island])
                                        if bsTemp != gen_island:
                                            tempBS += [bsTemp]
                                            [timeOne] = timeTable.loc[timeTable['BS'] == bsTemp,'Bottleneck']
                                            tempTime += [int(timeOne+.5)]
                                            
                                    timeTable = pd.DataFrame(list(zip(tempBS,tempTime)),columns =['BS','Bottleneck'])
                    
                                break
            
                        if optLocal == 'INFEASIBLE' or optLocal == 'TIME_LIMIT':
                            break 
            
            toc = time.time()
            print('###########Elapse Time for Local Search = ',toc-ticRep)
            print('Construct an initial solution.......')
            var_name = []
            var_value = []
            for gen in bsGenerators:
                for v in subG[gen].nodes():
                    var_name += ['X[%s,%s]'%(v,gen)]
                    var_value += [1]
            #warm = pd.DataFrame(list(zip(var_name,var_value)),columns =['varName','varVal'])
            #warm.to_csv(r'opt_LocalSearch%s.csv'%rep, index = False)#Check
            
            timeTable_sorted = timeTable.sort_values(['Bottleneck'])
            maxBS = timeTable_sorted['BS'].iloc[len(islands)-1]
            maxTime = timeTable_sorted['Bottleneck'].iloc[len(islands)-1]
            
            print('######### Warm Start Ready PPSR with warm objective = %s'%maxTime)            

            step = 3

    
        toc = time.time()
        print('Run %s'%rep)
        print('until trial %s'%trial)
        print('bestVal = ',bottleneck)
        print('Elapse Time = ',toc-ticRep)
        print('#######')
        print()
    
    resultTable = pd.DataFrame(list(zip(bestRepList,bestBottleneckList,compTimeList,bestTrialList,stepList)),columns =['Run','Best Obj','Comp Time','Trial','Step'])
    resultTable.to_csv(r'randLS_p%s_tl%s_rep%s.csv'%(int(timeHorizon),int(compTimeLimit),rep), index = False)#Check
