For the code and the details, refer to folders ../IEEE-118 and ../IEEE-300


folder 'output' contains:
opt_PPSRT(RST0)_p28_v21_CPUT257s_PC_20210820.csv is the optimal solution to the tree partitioning problem (upper bounding approach 1). It took 257 seconds.
opt_LS(PPSRT(RST0))_v17_CPUT40s.csv is the resulting plan from the local search method (upper bounding approach 2). It took 40 seconds. The restoration time of the resulting plan is 17 periods that is near optimal as the lower bound is 16 periods.


folder 'input' contains:
lines_500.csv
nodes_500


folder 'log' contains:
log_PPSRT(RST0)_p28_v21_CPUT257s_PC_20210820.txt is the log of the subgraph partitioning problem (upper bounding approach 3)
