Input files are
nodes_30_4BS_p48.csv
lines_30.csv

nodes_30_4BS_p48.csv (4 BS nodes and time horizon of 48 periods) has node information as follows
Bus: Bus ID	
Type: BS nodes, NBS nodes, Trans (Transshipment nodes), CL (Critical Load)	
Capacity (MW)	
Cranking Power (MW)	
Cranking Time (h)	
Ramping Time (h)	
Cranking Time (5 min)	
Ramping Time (5 min)	
ET (5 min) Earliest Start Time
LT (5 min) Latest Start Time
period1

lines_30.csv
Line (Transmission Line ID)	
Source, Target (Two End Nodes of each Edge)



