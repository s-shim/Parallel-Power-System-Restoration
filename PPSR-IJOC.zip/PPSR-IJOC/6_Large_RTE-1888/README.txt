code, data and result in folder '20220721'

For details, refer to ../5_Large_PEG-1354
