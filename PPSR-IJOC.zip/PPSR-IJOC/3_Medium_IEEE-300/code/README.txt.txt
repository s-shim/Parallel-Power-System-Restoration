Enhancement of the integer linear programming on IEEE-300

Run multiRuns20220701.py for each run to perform a sequence of three upperbounding approaches: Tree Partitioning, Local Search and Subgraph Partitioning 
Set numberOfRuns = ? (the number of runs)
The code sequentially perform multiple runs. (1 run = 8 cores)
The code can be modified to perform the multiple runs simultaneously on parallel machine. (1 supercomputing node = 16 runs = 128 cores)


For example, folder 'output' has the result from 16 runs.
rep15_opt_PPSRT(RST)_p22_v15_CPUT97s.csv is the optimal solution to the tree partitioning problem.(rep15_RST.csv is the random spanning tree which is the minimum spanning tree on the random weight in rep15_lines.csv.) The algorithm started with upper bound 22 periods, and the optimal value is 11 periods. It is performed for 97 seconds.
rep15_opt_LS_p15_v12_CPUT30s.csv is the resultng solution from the local search method. The resulting value is 12 periods. It took 30 seconds.
rep15_opt_PPSR_QiuLi_warm_v11_CPUT340s.csv is the final solution on the subgraph (rep15_RST(x)Plus.csv) to the subgraph partition problem. The final value is 11 periods which is optimal to the original PPSR problem. The final algorithm took 340 seconds.


Input files are
nodes_jason_300.csv
lines_jason_300.csv

nodes_jason_300.csv has node information as follows
Bus: Bus ID	
Type: BS nodes, NBS nodes, Trans (Transshipment nodes), CL (Critical Load)	
Capacity (MW)	
Cranking Power (MW)	
Cranking Time (h)	
Ramping Time (h)	
Cranking Time (5 min)	
Ramping Time (5 min)	
period1

lines_jason_300.csv
Line (Transmission Line ID)	
Source, Target (Two End Nodes of each Edge)



