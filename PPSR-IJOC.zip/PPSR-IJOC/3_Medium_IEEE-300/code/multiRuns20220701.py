from gurobipy import *
import pandas as pd
import networkx as nx
import myDictionaryMultiRuns20220701 as mrd
import time
import datetime
import random as rd

threads = 8
LB = 11
timeHorizon = 22
nodes = pd.read_csv('nodes_jason_300.csv')
lines = pd.read_csv('lines_jason_300.csv')
numberOfRuns = 16

for rep in range(numberOfRuns):
    print()
    print('Rep %s starts at %s'%(rep,datetime.datetime.now()))
    tic = time.time()
    rand = []
    for line in lines['Line']:
        rand += [rd.random()]
    lines['weight'] = rand#pd.read_csv('lines_jason_300_rep%s.csv'%rep)
    lines.to_csv(r'rep%s_lines.csv'%rep, index = False)#Check
    randMinST = mrd.minST(rep, lines)
    randMinST.to_csv(r'rep%s_RST.csv'%rep, index = False)#Check
    print('A random spanning tree is generated at ',datetime.datetime.now())
    
    print('Start solving PPSRT on the tree at ',datetime.datetime.now())
    ticTree = time.time()
    optSolution, BNT = mrd.PPSRT(rep, randMinST, nodes, timeHorizon)
    tocTree = time.time()
    CPUTime = tocTree - ticTree
    optSolution.to_csv(r'rep%s_opt_PPSRT(RST)_p%s_v%s_CPUT%ss.csv'%(rep,int(timeHorizon),int(BNT),int(CPUTime)), index = False)#Check

    print('Start Local Search at ',datetime.datetime.now())
    ticLS = time.time()
    warm, maxTime, CPUTLS = mrd.LS(rep,threads,int(BNT+.5),lines,nodes,optSolution)
    tocLS = time.time()
    warm.to_csv(r'rep%s_opt_LS_p%s_v%s_CPUT%ss.csv'%(rep,int(BNT+.5),int(maxTime),int(CPUTLS)), index = False)#Check

# =============================================================================
#     if int(maxTime+.5) <= 12:    
#         print('Warm start Tree Plus Cut at ',datetime.datetime.now())
#         treeGlobalPlus = mrd.RSTPlus(lines,nodes,warm,rep)
#         treeGlobalPlus.to_csv(r'rep%s_RST(x)Plus.csv'%rep, index = False)#Check
#     
#         ticFin = time.time()
#         finSolution, finVal = mrd.PPSR_QL_warm(rep,maxTime,treeGlobalPlus,nodes,warm)
#         tocFin = time.time()
#     
#         finSolution.to_csv(r'rep%s_opt_PPSR_QiuLi_warm_v%s_CPUT%ss.csv'%(rep,int(finVal),int(tocFin-ticFin)), index = False)#Check
# =============================================================================

    print('Warm start Tree Plus Cut at ',datetime.datetime.now())
    treeGlobalPlus = mrd.RSTPlus(lines,nodes,warm,rep)
    treeGlobalPlus.to_csv(r'rep%s_RST(x)Plus.csv'%rep, index = False)#Check

    ticFin = time.time()
    finSolution, finVal = mrd.PPSR_QL_warm(rep,maxTime,treeGlobalPlus,nodes,warm)
    tocFin = time.time()

    finSolution.to_csv(r'rep%s_opt_PPSR_QiuLi_warm_v%s_CPUT%ss.csv'%(rep,int(finVal),int(tocFin-ticFin)), index = False)#Check
