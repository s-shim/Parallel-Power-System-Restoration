from gurobipy import *
import pandas as pd
import networkx as nx

timeHorizon = 60
lines = pd.read_csv('lines_118.csv')
nodes = pd.read_csv('IEEE118_6BS_20210216_res5min_p60.csv')

G = nx.Graph()
for l in lines['Line']:
    [Source] = lines.loc[lines['Line'] == l,'Source']
    [Target] = lines.loc[lines['Line'] == l,'Target']
    G.add_edge(Source,Target)

bsGenerators = []
setI = []
for v in nodes['Bus']:
    [genType] = nodes.loc[nodes['Bus'] == v,'Type']
    if genType == 'BS':
        bsGenerators += [v]
# =============================================================================
#     if genType == 'BS+NBS':
#         bsGenerators += [v]
# =============================================================================
    if genType == 'NBS':
        setI += [v]
    if genType == 'CL':
        setI += [v]

# ILP Model
model = Model('GSS-Aggregate')

## Employ Variables
start_vars = []
start_names = []
for i in setI:
    for t in range(1,timeHorizon + 1):
        start_vars += [(i,t)]
        start_names += ['start[%s,%s]'%(i,t)]    
start = model.addVars(start_vars, vtype = GRB.BINARY, name = start_names)

bottleneck = model.addVar(vtype=GRB.CONTINUOUS, name="bottleneck")


## Add Constraints
### One time start
for i in setI:
    LHS = []
    for t in range(1,timeHorizon+1):
        LHS += [(1,start[i,t])]
    model.addConstr(LinExpr(LHS)==1, name='Eq(oneTimeSatrt)(%s)'%(i))

### Power Aggregation Constraints
for t in range(1,timeHorizon + 1):
    RHS = 0
    for bsNode in bsGenerators:
        periodNameBS = "period%s"%t
        [powerOutput_bs_t] = nodes.loc[nodes['Bus'] == bsNode,periodNameBS]
        RHS += powerOutput_bs_t 
    
    aggregation = []
    for i in setI:
        [type_i] = nodes.loc[nodes['Bus'] == i,'Type']
        if type_i != 'BS' and type_i != 'Trans':                
                for earlierT in range(1,t+1):
                    relationT = t - earlierT + 1
                    periodName = "period%s"%relationT
                    [powerOutput_i_t] = nodes.loc[nodes['Bus'] == i,periodName]
                    aggregation += [(powerOutput_i_t,start[i,earlierT])] 
    model.addConstr(LinExpr(aggregation)>=-RHS, name='Eq(powerAggregate)(%s)'%(t))

## Bottleneck 
for i in setI:
    LHS = [(1,bottleneck)]
    for t in range(1,timeHorizon + 1):
        LHS += [(-t, start[i,t])]
    model.addConstr(LinExpr(LHS)>=0, name='Eq.bottleneck(%s)'%(i))    

# =============================================================================
# ## [ET, LT] 
# for i in setI:
#     [ET_i] = nodes.loc[nodes['Bus'] == i,'ET (5 min)']
#     [LT_i] = nodes.loc[nodes['Bus'] == i,'LT (5 min)']
#     LHS_ET = []
#     LHS_LT = []
#     for t in range(1,timeHorizon + 1):
#         LHS_ET += [(t, start[i,t])]
#         LHS_LT += [(t, start[i,t])]
#     model.addConstr(LinExpr(LHS_ET)>=ET_i, name='Eq.ET(%s)'%(i))    
#     model.addConstr(LinExpr(LHS_LT)<=LT_i, name='Eq.LT(%s)'%(i))    
# =============================================================================

# Objective Function
## Objective Terms
objTerms = [(1,bottleneck)]                                
model.setObjective(LinExpr(objTerms), GRB.MINIMIZE)
        

# update and solve the model
model.update()
model.optimize()


# =============================================================================
# # read the optimal solution
# variableName = []
# variableValue = []
# for v in model.getVars():
#     if v.x > 0:
#         variableName += [v.varname]
#         variableValue += [v.x]
# 
# 
# optSolution = pd.DataFrame(list(zip(variableName, variableValue)),columns =['varName', 'varVal'])
# optSolution.to_csv(r'opt_118_6BS_20210216_res5min_p%s.csv'%timeHorizon, index = False)#Check
# =============================================================================
